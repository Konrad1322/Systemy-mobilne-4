//
//  AppDelegate.h
//  konrad
//
//  Created by student on 14/11/2023.
//  Copyright © 2023 SM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

